import streamlit as st
import chatbot
import stone_game
import home
import stone_game_new

def main():
    # ページ選択
    page = st.selectbox("ページを選択してください", ["home","チャットボット", "石取りゲーム","石取りゲーム(強)"])

    # ページに応じて関数を呼び出す
    if page =="home":
        home.hello()
    elif page == "チャットボット":
        chatbot.main()
    elif page == "石取りゲーム":
        stone_game.play_game()
    elif page == "石取りゲーム(強)":
        stone_game_new.play_game()

if __name__ == "__main__":
    main()

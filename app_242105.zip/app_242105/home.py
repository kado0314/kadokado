import streamlit as st

def hello():
    st.title("こんにちは!")
    st.write("変なチャットボットや石取りゲームがあります。")
    st.write("石取りゲーム(強)は負けません。")